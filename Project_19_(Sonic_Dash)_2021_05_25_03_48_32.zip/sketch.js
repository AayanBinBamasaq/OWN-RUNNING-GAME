var PLAY = 1;
var END = 0;
var gameState = PLAY;

var score;

var sonic, sonic_running, sonic_collided, jumpSound, background, backgroundImage, coin, coinImage, coinsGroup, coinSound, obstacle, obstacleImage, obstaclesGroup, invisibleGround, sun, sunImage, gameOver, gameOverImage;

function preload(){
  coinImage = loadImage("coin.png");
  sunImage = loadImage("sun.png");
  jumpSound = loadSound("jump.mp3");
  coinSound = loadSound("coin.wav");
  obstacleImage = loadImage("obstacle.png");
  sonic_running = loadAnimation("sonic running.gif");
  sonic_collided = loadImage("sonic_Collided.png");
  backgroundImage = loadImage("background.png");
  gameOverImage = loadImage("gameover.png");
}

function setup() {
  createCanvas(600, 325);
  
  coinsGroup = new Group();
  obstaclesGroup = new Group();
  
  background = createSprite(0, 140, 10, 10);
  background.addImage(backgroundImage);
  background.scale = 2
  sonic = createSprite(80, 260, 10, 10);
  sonic.addAnimation("running", sonic_running);
  sonic.addAnimation("collided", sonic_collided);
  sonic.scale = 0.25;
  sun = createSprite(515, 70, 10, 10);
  sun.addImage(sunImage);
  sun.scale = 0.235;
  invisibleGround = createSprite(25, 320, 300, 50);
  invisibleGround.visible = false;
  gameOver = createSprite(300, 150);
  gameOver.addImage(gameOverImage);
  gameOver.scale = 0.75;
  gameOver.visible = false;
  score = 0;
  
  sonic.setCollider("rectangle", 10, 5, 250, 300)
  
}

function draw() {
  if(gameState === PLAY){
    
    
    background.velocityX = -9;
    if(background.x<0){
    background.x = background.width/1;
    }
    
    if(keyDown("space") && sonic.y >= 200){
    sonic.velocityY = -15;
    jumpSound.play();
    }
    
    if(sonic.isTouching(coinsGroup)){
      score = score+1;
      coinsGroup[0].destroy();
      coinSound.play();
    }
    
    if(obstaclesGroup.isTouching(sonic)){
      gameState = END;
    }
    
    sonic.velocityY = sonic.velocityY+0.8;
    
    spawnCoins();
    spawnObstacles();
    
  }else if(gameState === END){
    obstaclesGroup.setVelocityXEach(0);
    coinsGroup.setVelocityXEach(0);
    sonic.velocityY = 0;
    obstaclesGroup.setLifetimeEach(-1);
    coinsGroup.setLifetimeEach(-1);
    background.velocityX = 0;
    sonic.changeAnimation("collided", sonic_collided);
    sonic.scale = 0.25;
    gameOver.visible = true;
    sonic.x = 100;
    sonic.y = 230;
    
  }
  drawSprites();
  
  sonic.collide(invisibleGround);
  
  fill("black");
  textSize(40);
  text("score:" + score, 10, 40);
}

function spawnCoins(){
  if(frameCount%60 === 0){
    coin = createSprite(550, 280, 50, 50);
    coin.y = Math.round(random(150, 250))
    coin.addImage(coinImage);
    coin.scale = 0.235;
    coin.velocityX = -6-score/2;
    coin.lifetime = 200;
    
    sonic.depth = coin.depth;
    sonic.depth = sonic.depth+1;
    
    gameOver.depth = coin.depth;
    gameOver.depth = gameOver.depth+1;
    
    coinsGroup.add(coin);
    coin.setCollider("rectangle", 10, 5, 300, 300)
  }
}

function spawnObstacles(){
  if(frameCount%200 === 0){
    obstacle = createSprite(550, 270, 10, 10);
    obstacle.addImage(obstacleImage);
    obstacle.velocityX = -9-score/2;
    obstacle.lifetime = 150;
    obstacle.scale = 0.25;
    
    sonic.depth = obstacle.depth;
    sonic.depth = sonic.depth+1;
    
    gameOver.depth = obstacle.depth;
    gameOver.depth = gameOver.depth+1;
    
    obstaclesGroup.add(obstacle);
  }
}